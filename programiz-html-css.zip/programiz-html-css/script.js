// FIXED SHARE - Always goes through
function getAppLink(){
  // If app is still a file on phone, use a clean message without broken link
  let link = window.location.href;
  if(link.startsWith("file:") || link === "about:blank"){
    return "McOCHALLY App - Ask Admin for link";
  }
  return link.split('?')[0];
}

function shareApp(){
  let link = getAppLink();
  let text = "Karibu McOCHALLY FLEXI CREDIT! 💰\n\nBorrow fast - Interest 30% Flat\nPay to M-PESA: 0790885177\n\nOpen App here:\n" + link + "\n\n✨ WE ARE READY TO SERVE YOU";
  // Use api.whatsapp.com - works on ALL phones, unlike wa.me/?text=
  let waUrl = "https://api.whatsapp.com/send?text=" + encodeURIComponent(text);
  // Try to open WhatsApp
  let win = window.open(waUrl, "_blank");
  // If popup blocked, copy + show
  setTimeout(function(){
    if(!win || win.closed){
      if(navigator.clipboard){
        navigator.clipboard.writeText(text).then(function(){
          alert("WhatsApp blocked popup.\n\nI have COPIED the message.\n\nNow open WhatsApp yourself and PASTE it.");
        });
      } else {
        prompt("Copy this message and paste in WhatsApp:", text);
      }
    }
  }, 500);
}

function copyAppLink(){
  let link = getAppLink();
  let text = "McOCHALLY App: " + link;
  if(navigator.clipboard){
    navigator.clipboard.writeText(link).then(function(){
      document.getElementById("shareMsg").innerText = "✅ Link Copied! Paste it on WhatsApp.";
      alert("Link Copied:\n"+link+"\n\nNow paste it in WhatsApp.");
    });
  } else {
    prompt("Copy this link:", link);
  }
}

// FIXED RECEIPT SHARE
function shareReceipt(receiptNo, name, principal, paid, mpesaCode){
  let text = "🧾 McOCHALLY FLEXI CREDIT - RECEIPT ✅\n\nReceipt: "+receiptNo+"\nName: "+name+"\nBorrowed: KES "+principal+"\nPaid: KES "+paid+"\nM-PESA Code: "+(mpesaCode||"-")+"\nStatus: CLEARED ✅ - Balance 0\n\nThank you! Karibu tena!\nMcOCHALLY - WE ARE READY TO SERVE YOU";
  // FIX: use api.whatsapp.com instead of wa.me/?text=
  let waUrl = "https://api.whatsapp.com/send?text=" + encodeURIComponent(text);
  let win = window.open(waUrl, "_blank");
  setTimeout(function(){
    if(!win || win.closed){
      if(navigator.clipboard){
        navigator.clipboard.writeText(text).then(function(){
          alert("WhatsApp popup was blocked.\n\nI COPIED the Receipt.\nOpen WhatsApp and PASTE it.");
        });
      } else {
        prompt("Copy Receipt and paste in WhatsApp:", text);
      }
    }
  }, 500);
}console.log("from script file");